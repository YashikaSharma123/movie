package com.movieapp.exception;

public class ActorNotFoundException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public ActorNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ActorNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
