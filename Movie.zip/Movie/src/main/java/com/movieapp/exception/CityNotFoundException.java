package com.movieapp.exception;

public class CityNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
	
		public CityNotFoundException() {
			super();
			// TODO Auto-generated constructor stub
		}
	
		public CityNotFoundException(String message) {
			super(message);
			// TODO Auto-generated constructor stub
		}
	

}
