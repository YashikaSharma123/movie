package com.movieapp.exception;

public class CategoryNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
	
		public CategoryNotFoundException() {
			super();
			// TODO Auto-generated constructor stub
		}
	
		public CategoryNotFoundException(String message) {
			super(message);
			// TODO Auto-generated constructor stub
		}
	

}
