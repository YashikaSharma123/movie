package com.movieapp.model;

public class User {
	private String loginId;
	private String password;
	private String mobileno;
	private String username;
	
	public User(String loginId, String password, String mobileno, String username) {
		super();
		this.loginId = loginId;
		this.password = password;
		this.mobileno = mobileno;
		this.username = username;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User [loginId=" + loginId + ", password=" + password + ", mobileno=" + mobileno + ", username="
				+ username + "]";
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	

}
