package com.movieapp.model;

public class Admin {
	private String loginId;
	private String password;
	private String mobileno;
	private String adminname;
	
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public Admin() {
		super();
		
	}
	public Admin(String loginId, String password, String mobileno, String adminname) {
		super();
		this.loginId = loginId;
		this.password = password;
		this.mobileno = mobileno;
		this.adminname = adminname;
	}
	@Override
	public String toString() {
		return "Admin [loginId=" + loginId + ", password=" + password + ", mobileno=" + mobileno + ", adminname="
				+ adminname + "]";
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAdminname() {
		return adminname;
	}
	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	
	


}
