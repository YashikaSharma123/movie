package com.movieapp.service;
import java.util.ArrayList;
import java.util.List;

import com.movieapp.dao.AdminDao;
import com.movieapp.dao.AdminDaoImpl;
import com.movieapp.exception.IdNotFoundException;
import com.movieapp.model.Admin;
import com.movieapp.model.Movie;

public class AdminServiceImpl implements AdminService{
	
	AdminDao adminDAO=new AdminDaoImpl();
	Admin admin=null;
	public String adminLogin(String loginid, String password) throws IdNotFoundException{
		admin=adminDAO.adminLogin(loginid, password);
		if(admin==null)
			throw new IdNotFoundException("Invalid Admin");
		return "Logined";	
	}
	public void addMovie(Movie movie) {
		adminDAO.addOneMovie(movie);
	}

	public void deleteMovie(int movieid) throws IdNotFoundException {
		int result=adminDAO.deleteOneMovie(movieid);
		if(result==0)
			throw new IdNotFoundException("Invalid id");
		
	}

	public void updateMovie(int movieid, int price) throws IdNotFoundException {
		int result=adminDAO.updateOneMovie(movieid, price);
		if(result==0)
			throw new IdNotFoundException("Invalid id");
		}

	public Movie getMovieById(int movieid) throws IdNotFoundException {
		//List<Movie> movieList = (List<Movie>) adminDAO.findMovieById(movieid);
		Movie movie = adminDAO.findMovieById(movieid);
		
		
		if(movie==null)
			throw new IdNotFoundException("Invalid ID");
		return movie;
		
	}
	
	

}
