package com.movieapp.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.movieapp.dao.UserDaoImpl;
import com.movieapp.exception.ActorNotFoundException;
import com.movieapp.exception.ActressNotFoundException;
import com.movieapp.exception.CategoryNotFoundException;
import com.movieapp.exception.CityNotFoundException;
import com.movieapp.exception.InvalidUserException;
import com.movieapp.exception.MovieNotFoundException;
import com.movieapp.exception.TheatreNotFoundException;
import com.movieapp.model.Movie;
import com.movieapp.model.User;
import com.movieapp.service.MovieService;
import com.movieapp.service.MovieServiceImpl;
import com.movieapp.service.UserService;
import com.movieapp.service.UserServiceImpl;

public class UserMain {
	public static void main(String[] args) {
		UserService u1=new UserServiceImpl();
		//User u2=new User("Yashikasharma","yashika","98876","yashika");
		//u1.userSignup(u2);
		List<Movie> movieList=new ArrayList<>();
		User u2=new User();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Login or Signup");
		String login=sc.next();
		
		if(login.equals("login")) {
			
			try {
				System.out.println("Enter your loginid");
				String loginid=sc.next();
				System.out.println("Enter your password");
				String password=sc.next();
				System.out.println(u1.userLogin(loginid,password));
				MovieService services=new MovieServiceImpl();
				
				ArrayList<String> citys=new ArrayList<String>(Arrays.asList("delhi","bangalore","haryana")); 
				System.out.println("Enter your city");
				String city=sc.next();

						try {
							movieList=services.getMovieByCity(city);
							
							System.out.println("Enter price low | high");
							String val=sc.next();
							if(val.equals("low")) {
								movieList
								.stream()
								.sorted((o1,o2)->o1.getPrice().compareTo(o2.getPrice()))
								.forEach(emp->System.out.println(emp));
							}
							if(val.equals("high")) {
								movieList
								.stream()
								.sorted((o1,o2)->o2.getPrice().compareTo(o1.getPrice()))
								.forEach(emp->System.out.println(emp));
							}
						}
							 catch (CityNotFoundException e) {
									
									e.printStackTrace();
								}
							
									
							System.out.println("Enter theatre");
							String theatre=sc.next();
							services.getMovieByTheatre(theatre).forEach(System.out::println);;
							
							System.out.println("Enter date");
							String dates=sc.next();
							services.getMovieByDates(dates).forEach(System.out::println);;
	
							System.out.println("Enter category");
							String category=sc.next();
							services.getMovieByCategory(category).forEach(System.out::println);;
							
							
							System.out.println("Enter actor");
							String actor=sc.next();
							services.getMovieByActor(actor).forEach(System.out::println);;
	
							System.out.println("Enter actress");
							String actress=sc.next();
							services.getMovieByActress(actress).forEach(System.out::println);;
	
							System.out.println("Enter rating");
							int rating=sc.nextInt();
							services.getMovieByRating(rating).forEach(System.out::println);;
	
							
							
							
							
			}catch (InvalidUserException e) {
				
				e.printStackTrace();
			} catch (TheatreNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MovieNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ActressNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ActorNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CategoryNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
						
		if(login.equals("Signup")) {
			
			System.out.println("Enter your loginid");
			String loginid=sc.next();
			System.out.println("Enter your password");
			String password=sc.next();
			System.out.println("Enter your mobileno");
			String mobileno=sc.next();
			System.out.println("Enter your username");
			String username=sc.next();
			u1.userSignup(u2);
		}
		
		
		
		
		
		
					
			}
		}
	
	
