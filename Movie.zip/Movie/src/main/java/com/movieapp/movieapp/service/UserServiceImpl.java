package com.movieapp.service;

import com.movieapp.exception.InvalidUserException;
import com.movieapp.model.User;


public class UserServiceImpl implements UserService{

	public void userLogin(int loginid, String password) throws InvalidUserException {
		// TODO Auto-generated method stub
		
	}

	public void userSignup(User user) {
		// TODO Auto-generated method stub
		
	}
	
	

}
