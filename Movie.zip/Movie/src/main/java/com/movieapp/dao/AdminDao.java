package com.movieapp.dao;

import com.movieapp.model.Admin;
import com.movieapp.model.Movie;

public interface AdminDao {
	
	Admin adminLogin(String loginid,String password);
	void addOneMovie(Movie movie);
	int deleteOneMovie(int movieid);
	int updateOneMovie(int movieid,int price);
	Movie findMovieById(int movieid) ;
	

}
