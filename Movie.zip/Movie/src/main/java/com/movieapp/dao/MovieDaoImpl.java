package com.movieapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.movieapp.model.Movie;

public class MovieDaoImpl implements MovieDao{
	List<Movie> movieList = new ArrayList<>();
	
	public List<Movie> findMovieByCity(String city) {
		String sql = "select * from movie where city =?";
		Connection connection = DBConnection.openConnection();
		PreparedStatement statement = null;
		
		try {
			statement = connection.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			statement.setString(1,city);
			ResultSet rs = statement.executeQuery();
			
			while(rs.next()) {
				
				int movieid = rs.getInt(1);
				String name = rs.getString("name");
				String city1 = rs.getString("city");
				String theatre = rs.getString("theatre");
				String language = rs.getString("language");
				String category = rs.getString("category");
				String director = rs.getString("director");
				String actor = rs.getString("actor");
				String actress = rs.getString("actress");
				String dates = rs.getString("dates");
				int price = rs.getInt("price");
				int  rating= rs.getInt("rating");
				
				Movie movie = new Movie(movieid, name,city1, theatre, language,category,director,actor,actress,dates,price,rating);				
				movieList.add(movie);
			}
			} catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			if(statement!=null)
				try {
					statement.close();
				}catch(SQLException e) {
					System.out.println(e.getMessage());
				}
			DBConnection.closeConnection();

		}
		return movieList;

	}

	public List<Movie> findMovieByTheatre(String theatre)  {
		
		List<Movie> movieList1 = new ArrayList<>();
		movieList1=movieList.stream().filter((t)->t.getTheatre().equals(theatre)).collect(Collectors.toList());
		return movieList1;

	}

	public List<Movie> findMovieByPrice(int price)  {
		List<Movie> movieList1 = new ArrayList<>();
		movieList1=movieList.stream().filter((t)->t.getPrice().equals(price)).collect(Collectors.toList());
		return movieList1;
		
		}
	

	public List<Movie> findMovieByDates(String dates) {
		
		List<Movie> movieList1 = new ArrayList<>();
		movieList1=movieList.stream().filter((t)->t.getDates().equals(dates)).collect(Collectors.toList());
		return movieList1;

	}

	public List<Movie> findMovieByCategory(String category)  {
		List<Movie> movieList1 = new ArrayList<>();
		movieList1=movieList.stream().filter((t)->t.getCategory().equals(category)).collect(Collectors.toList());
		return movieList1;

	}

	public List<Movie> findMovieByRating(int rating)  {
		List<Movie> movieList1 = new ArrayList<>();
		movieList1=movieList.stream().filter((t)->t.getRating().equals(rating)).collect(Collectors.toList());
		return movieList1;
	}

	public List<Movie> findMovieByActor(String actor){
		List<Movie> movieList1 = new ArrayList<>();
		movieList1=movieList.stream().filter((t)->t.getActor().equals(actor)).collect(Collectors.toList());
		return movieList1;
	}

	public List<Movie> findMovieByActress(String actress)  {
		
		List<Movie> movieList1 = new ArrayList<>();
		movieList1=movieList.stream().filter((t)->t.getActress().equals(actress)).collect(Collectors.toList());
		return movieList1;
	}
}
