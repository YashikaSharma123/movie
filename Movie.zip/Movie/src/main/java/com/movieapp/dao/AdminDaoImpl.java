package com.movieapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.movieapp.model.Admin;
import com.movieapp.model.Movie;
import com.movieapp.model.User;

public class AdminDaoImpl implements AdminDao{

	public Admin adminLogin(String loginid, String password) {
		String sql = "select * from admin where loginid =? and password=?";
		Connection connection = DBConnection.openConnection();
		PreparedStatement statement = null;
		Admin admin =null;
		
		try {
			statement = connection.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			statement.setString(1,loginid);
			statement.setString(2,password);
			ResultSet rs = statement.executeQuery();
			
			while(rs.next()) {
				String mobileno=rs.getString(3);
				String username=rs.getString(4);
				
					
				
				 admin = new Admin(loginid,password,mobileno,username);
				//movieList.add(movie);
			}
			} catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			if(statement!=null)
				try {
					statement.close();
				}catch(SQLException e) {
					System.out.println(e.getMessage());
				}
			DBConnection.closeConnection();

		}
		return admin;

	}

	public void addOneMovie(Movie movie) {
		String sql = "insert into movie values(?,?,?,?,?,?,?,?,?,?,?,?)";
		Connection connection = DBConnection.openConnection();
		PreparedStatement statement = null;
		try {
		statement = connection.prepareStatement(sql);
		statement.setInt(1, movie.getMovieid());
		statement.setString(2, movie.getName());
		statement.setString(3, movie.getCity());
		statement.setString(4, movie.getTheatre());
		statement.setString(5, movie.getLanguage());
		statement.setString(6, movie.getCategory());
		statement.setString(7, movie.getDirector());
		statement.setString(8, movie.getActor());
		statement.setString(9, movie.getActress());
		statement.setString(10, movie.getDates());
		statement.setInt(11, movie.getPrice());
		statement.setInt(12, movie.getRating());	
		statement.execute();
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			if(statement!=null)
				try {
					statement.close();
				}catch(SQLException e) {
					System.out.println(e.getMessage());
				}
			DBConnection.closeConnection();
		}

	}

	public int deleteOneMovie(int movieid) {
		String sql = "delete from Movie where movieid=?";
		Connection connection = DBConnection.openConnection();
		PreparedStatement statement = null;
		int result=0;
		try {
		statement = connection.prepareStatement(sql);
		statement.setInt(1, movieid);
		result = statement.executeUpdate();
		System.out.println(result);
		} catch(SQLException e) {
			e.printStackTrace();
		}finally {
			if(statement!=null)
				try {
					statement.close();
				}catch(SQLException e) {
					System.out.println(e.getMessage());
				}
			DBConnection.closeConnection();
		}

		return result;
	}

	public int updateOneMovie(int movieid, int price){
		String sql = "update Movie set price=? where movieid=?";
		Connection connection = DBConnection.openConnection();
		PreparedStatement statement = null;
		int result=0;
		try {
		statement = connection.prepareStatement(sql);
		statement.setInt(1, price);
		statement.setInt(2, movieid);
		result = statement.executeUpdate();
		
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			if(statement!=null)
				try {
					statement.close();
				}catch(SQLException e) {
					System.out.println(e.getMessage());
				}
			DBConnection.closeConnection();
		}
		return result;
		
	}

	public Movie findMovieById(int movieid) {
		String sql = "select * from movie where movieid=?";
		Connection connection = DBConnection.openConnection();
		PreparedStatement statement = null;
		Movie movie =null;
		//List<Movie> movieList=new ArrayList<>();
		try {
			statement = connection.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			statement.setInt(1,movieid);
			ResultSet rs = statement.executeQuery();
			
			while(rs.next()) {
				String name = rs.getString("name");
				String city = rs.getString("city");
				String theatre = rs.getString("theatre");
				String language = rs.getString("language");
				String category = rs.getString("category");
				String director = rs.getString("director");
				String actor = rs.getString("actor");
				String actress = rs.getString("actress");
				String dates = rs.getString("dates");
				int price = rs.getInt("price");
				int  rating= rs.getInt("rating");
				
					
				
				 movie = new Movie(movieid, name,city, theatre, language,category,director,actor,actress,dates,price,rating);
				//movieList.add(movie);
			}
			} catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			if(statement!=null)
				try {
					statement.close();
				}catch(SQLException e) {
					System.out.println(e.getMessage());
				}
			DBConnection.closeConnection();
		}
		return movie;
	}
}
