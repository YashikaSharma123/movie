package com.movieapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	static Connection connection;
	public static Connection openConnection() {
		try {
			//String sql = "create table Movie(movieid integer,name varchar(30),city varchar(30),theatre varchar(20),language varchar(30),category varchar(20),director varchar(20),actor varchar(20),actress varchar(20),date varchar(20),price integer)";
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String username = "system";
			String password = "system";
		connection = DriverManager.getConnection(url,username,password);
		//PreparedStatement statement = connection.prepareStatement(sql);
		//statement.execute();
		//statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	public static void closeConnection() {
		if(connection!=null)
			try {
			connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		System.out.println("closeConnection");
	}


}
